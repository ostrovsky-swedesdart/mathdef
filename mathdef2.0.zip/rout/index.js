"use strict";

var pi = Math.PI;

class PI {
constructor () {
this.pi = pi;
return this.pi;
}
};

class Abu {};

module.exports = { PI, Abu};